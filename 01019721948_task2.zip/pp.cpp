//#include <iostream>
//#include <bits/stdc++.h>
//#include <cstdlib>
//#include "robot.h"
//#include "user.h"
//using namespace std;

//int main(){
//    vector <Robot> r;
//    vector <User> u;
//    map <string , string > map_rent;
//    map <string,string> :: iterator itr;
//    Robot robot;
//    User user;

//     string name , date;
//    int count_r = 0;
//    int count_u = 0;
//    int count = 0;
//    int num , check = 0 ;
//    string selection_num = "1" ;
//    cout << "Welcome Admin To Robot Rental!"<<"\n";
//    cout << "Main Menu : " << endl;
//    cout << "           1 - Add Robot\n"
//         << "           2 - Add User\n"
//         << "           3 - Display All Robots\n"
//         << "           4 - Display All Users\n"
//         << "           5 - Search for robot by name\n"
//         << "           6 - Search for user by name\n"
//         << "           7 - Rent Robot\n"
//         << "           8 - Exit\n";



//    while (selection_num != "8") {
//        cout << "-------------------------------------"<<endl;
//        cout << "Ur choice => ";
//        cin >> selection_num ;
//        cout << "-------------------------------------"<<endl;
//        int num_after_coversion=0;
//        stringstream s;
//        if (selection_num >= "1" && selection_num <= "8") {
//            s << selection_num;
//            s >> num_after_coversion ;
//        }

//        else {

//            cout << "Invalid Selection [Defualt = 1]"<<endl;
//            selection_num = "1";
//            s<<selection_num;
//            s>> num_after_coversion;
//            cout << "\n";

//        }

//        switch (num_after_coversion) {

//           case 1 :

//            cout << "Number of Robots => ";
//            cin >> num;

//            if ( num <= 0 ) {
//                cout << "Number Of Robots isn't valid [default num = 1]\n";
//                num = 1;
//            }


//            //makeing array objects from class Robot with number of robots (regular = num) and added if founded
//            for (int i = 0 ; i < num ; i++) {


//                string name ;
//                int price_per_day ;
//                string function;
//                cout << "\n";
//               printf("       Robot %i \n",i+1);
//                cout << "name :             " ;
//                cin >> name ;
//                cout << "price per day :    " ;
//                cin >>  price_per_day;
//                cout << "Function id :      " ;
//                cin >> function;
//                cout << "\n";

//                robot.add_robot(name , price_per_day , function);
//                r.push_back(robot);
//                count_r++;


//            }

//             break;

//        case 2 :
//            cout << "Number of Users => ";
//            cin >> num;

//            if (num <= 0 ) {
//                cout << "Number Of User isn't valid [default num = 1]\n";
//                num = 1;

//            }


//            //makeing array objects from class Robot with number of robots (regular = num) and added if founded
//            for (int i = 0 ; i < num ; i++) {


//                string name , mail ,  phone_number  ;

//                cout << "\n";
//                printf("         User %i \n",i+1);
//                cout << "name :           " ;
//                cin >> name ;
//                cout << "phone_number :   " ;
//                cin >>  phone_number ;
//                cout << "mail :           " ;
//                cin >> mail;
//                cout << "\n";


//                user.add_user(name , phone_number , mail);
//                u.push_back(user);
//                count_u++;
//            }

//             break;

//        case 3 :

//            if (r.empty()) {
//                check = 0;
//                cout << "-----------> U should add Robots and Users at the first <----------- \n";
//                break;
//            }
//            else {
//                check =1;
//            }

//            for (int j = 0 ; j<count_r ; j++) {

//                r[j].display_robot(j);

//            }

//            break;

//        case 4 :

//            if (u.empty()) {
//                check = 0;
//                cout << "-----------> U should add Robots and Users at the first <----------- \n";
//                break;
//            }
//            else {
//                check =1;
//            }

//            for (int j = 0 ; j<count_u ; j++) {

//                u[j].display_users(j);

//            }

//            break;


//        case 5 :

//            if (r.empty()) {
//                check = 0;
//                cout << "-----------> U should add Robots and Users at the first <----------- \n";
//                break;
//            }
//            else {
//                check =1;
//            }

//            //search for robot by name

//                cout << "Robot Name => ";
//                cin >> name;
//                for (int i = 0 ; i < count_r ; i++) {

//                    if (r[i].get_name() == name  ) {
//                       r[i].search_robot(name,i);
//                    }
//                }
//            break;

//        case 6 :

//            if (u.empty()) {
//                cout << "-----------> U should add Robots and Users at the first <----------- \n";
//                break;
//            }


//            //search for user by name

//            cout << "User Name => ";
//            cin >> name;
//            for (int i = 0 ; i < count_u ; i++) {

//                if (u[i].get_name() == name  ) {
//                   u[i].search_user(name , i);
//                }
//            }

//            break;

//        case 7 :

//            if (r.empty() && u.empty()) {
//                cout << "-----------> U should add Robots and Users at the first <----------- \n";
//                break;
//            }

//               int count = 0;
//               //display users
//                for (int j = 0 ; j<count_u ; j++) {
//                    u[j].display_users(j);
//                }

//                int user_num , robo_num ;
//                int day , month  , year;
//                cout << "Which User want to rent Robot ?! \n\n"
//                     << "              User : ";
//                cin >> user_num ;
//                if (user_num < 1 || user_num > count_u ) {
//                    user_num = 1;
//                    cout << "Invalid User [Default = 1] \n";
//                }

//                cout << "  Enter Date \n"
//                     << "  Day :   \t"; cin >> day;
//                cout << "  Month : \t"; cin >> month;
//                cout << "  Year :  \t" ; cin >> year;

//               date = u[user_num].rent_user(day , month , year) ;
//               cout << "\n\n";

//               for (int i = 0 ; i < count_r; i++) {

//                   if ( r[i].get_rent() == false ) {
//                       r[i].display_robot(i);

//                   }

//               }

//               cout << "Which robot does the user want to rent ?! \n\n"
//                    << "              Robot : ";
//               cin >> robo_num ;
//               if (robo_num < 1 || robo_num > count_r ) {

//                   cout << "Invalid Robot [Default = 1] \n";
//               }

//              // r[robo_num-1].set_rent(true);

//               map_rent[r[robo_num-1].get_name()] = date;


//               for (itr = map_rent.begin() ; itr != map_rent.end() ; itr++) {
//                if (itr->second == date){
//                    r[robo_num-1].set_rent(true);
//                       /* if (itr->first == r[i].get_name() ) {
//                            r[i].set_rent(true);
//                        }*/

//                }

//               }

//            break;

//    /*    case 8 :
//            cout << "=========> Program is Closed <=================\n";
//            return 0 ;


//        default :
//         cout << "Please renter your choice\n";
//         break;*/

//    }

//    }


// return 0;
//}
