#include <bits/stdc++.h>

using namespace std;

int main()
{
   printf("\n\t*    *  *****\n\t*    *    *  \n\t"
          "******    *  \n\t*    *    *  \n\t*    *  *****\n\n");  // I think this is the best way rather than using loops inside each other
   return 0;
}
